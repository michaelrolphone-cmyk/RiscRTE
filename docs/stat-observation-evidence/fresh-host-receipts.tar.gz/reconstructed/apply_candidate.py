from pathlib import Path
root=Path('/workspace/shared/stat-observation-recovery/runtime')
def edit(path,a,b):
 p=root/path;s=p.read_text();assert a in s,(path,a);p.write_text(s.replace(a,b,1))
edit('src/bootstrap/StorageFilesVolumeAdapter.h','#include <climits>','#include <climits>\n#include "StatObservation.h"')
edit('src/bootstrap/StorageFilesVolumeAdapter.h','int32_t stat(const char* path,risc_storage_files_stat_v1* out) {','int32_t stat(const char* path,risc_storage_files_stat_v1* out,StatObservation* observation=nullptr) {')
edit('src/bootstrap/StorageFilesVolumeAdapter.h','''    int32_t rc=before();if(rc!=RISC_FILES_OK)return rc;
    if(files_) {
      risc_storage_files_stat_v1 value{};value.struct_size=sizeof(value);
      rc=directResult(files_->stat(files_->context,path,&value));if(rc!=RISC_FILES_OK)return rc;''','''    int32_t rc=before(observation,true);if(rc!=RISC_FILES_OK)return rc;
    if(files_) {
      risc_storage_files_stat_v1 value{};value.struct_size=sizeof(value);
      if(observation)observation->flags|=StatMetadata;
      const int32_t native=files_->stat(files_->context,path,&value);
      if(observation)observation->metadataStatus=native;
      rc=directResult(native);if(rc!=RISC_FILES_OK)return rc;''')
edit('src/bootstrap/StorageFilesVolumeAdapter.h','''    int32_t native=fs_->metadata(context(),path,&value);
    rc=after(native==RISC_STORAGE_FS_OK,native!=RISC_STORAGE_FS_OK);''','''    if(observation)observation->flags|=StatMetadata;
    int32_t native=fs_->metadata(context(),path,&value);
    if(observation)observation->metadataStatus=native;
    rc=after(native==RISC_STORAGE_FS_OK,native!=RISC_STORAGE_FS_OK,observation);''')
edit('src/bootstrap/StorageFilesVolumeAdapter.h','  int32_t before() {','  int32_t before(StatObservation* observation=nullptr,bool pre=false) {')
edit('src/bootstrap/StorageFilesVolumeAdapter.h','    int32_t state=fs_->state.observe(context());','''    int32_t state=fs_->state.observe(context());
    if(observation){
      ++observation->stateCalls;
      if(pre)observation->preState=state;
      else if(observation->postState==INT32_MIN)observation->postState=state;
      else observation->finalState=state;
    }''')
edit('src/bootstrap/StorageFilesVolumeAdapter.h','''  int32_t after(bool success,bool ambiguous) {
    int32_t rc=before();if(rc==RISC_FILES_RETAINED)return rc;''','''  int32_t after(bool success,bool ambiguous,StatObservation* observation=nullptr) {
    int32_t rc=before(observation);if(rc==RISC_FILES_RETAINED)return rc;''')
edit('src/bootstrap/StorageFilesVolumeAdapter.h','      bool ready=volume_->base.ready(context());rc=before();','''      if(observation)observation->flags|=StatReady;
      bool ready=volume_->base.ready(context());
      if(observation&&ready)observation->flags|=StatReadyTrue;
      rc=before(observation);''')
edit('src/bootstrap/RuntimeFiles.h','  int32_t stat(const char*p,risc_storage_files_stat_v1*s){return call([&]{return files_.stat(p,s);});}','''  // Caller-owned output; initialized for every outcome and never stored.
  int32_t stat(const char*p,risc_storage_files_stat_v1*s,StatObservation* observation=nullptr){if(observation)*observation=emptyStatObservation();return call([&]{return files_.stat(p,s,observation);},observation);}''')
edit('src/bootstrap/RuntimeFiles.h','''  template<class F>int32_t call(F f){
    if(retained())return RISC_FILES_RETAINED;
    if(!bound())return RISC_FILES_UNAVAILABLE;''','''  template<class F>int32_t call(F f,StatObservation* observation=nullptr){
    if(retained()){if(observation)observation->flags|=StatRetained;return RISC_FILES_RETAINED;}
    if(!bound())return RISC_FILES_UNAVAILABLE;
    if(observation)observation->flags|=StatBound;''')
edit('src/runtime/serial/Files.h',' void (*controlObserved)(uint32_t,uint32_t,const char*,uint32_t,bool)=nullptr;',''' void (*controlObserved)(uint32_t,uint32_t,const char*,uint32_t,bool)=nullptr;
 // Accepted STAT only. Copy the borrowed output synchronously; no provider,
 // allocation, wait or reentry. Identity describes the actual dispatch.
 void (*statObserved)(uint32_t,uint32_t,uint64_t,int32_t,const RiscBoot::StatObservation&)=nullptr;''')
edit('src/runtime/serial/Files.cpp','''  }else if(!strcmp(cmd,"STAT") && count==5){risc_storage_files_stat_v1 st{sizeof(st),0,0,0};int32_t rc=ns->files->stat(path_,&st);checkRetention();reply(retained_?RISC_FILES_RETAINED:rc,"STAT %u %llu",unsigned(st.flags),(unsigned long long)st.size);}''','''  }else if(!strcmp(cmd,"STAT") && count==5){
   risc_storage_files_stat_v1 st{sizeof(st),0,0,0};RiscBoot::StatObservation observation;
   int32_t rc=ns->files->stat(path_,&st,hooks_.statObserved?&observation:nullptr);
   checkRetention();const int32_t status=retained_?RISC_FILES_RETAINED:rc;
   if(hooks_.statObserved)hooks_.statObserved(replySession_,replySequence_,ns->id,status,observation);
   reply(status,"STAT %u %llu",unsigned(st.flags),(unsigned long long)st.size);
  }''')
edit('src/ports/esp32s3/NativeSerialFiles.h','using ControlObserver=', 'using StatObserver=void(*)(uint32_t,uint32_t,uint64_t,int32_t,const RiscBoot::StatObservation&);\nusing ControlObserver=')
edit('src/ports/esp32s3/NativeSerialFiles.h','ControlObserver observer=nullptr);','ControlObserver observer=nullptr,StatObserver stat=nullptr);')
edit('src/ports/esp32s3/NativeSerialFiles.cpp','  ControlObserver observer=nullptr;','  ControlObserver observer=nullptr;StatObserver stat=nullptr;')
edit('src/ports/esp32s3/NativeSerialFiles.cpp','Check platformSafe,ControlObserver observer){','Check platformSafe,ControlObserver observer,StatObserver stat){')
edit('src/ports/esp32s3/NativeSerialFiles.cpp','state.observer=observer;','state.observer=observer;state.stat=stat;')
edit('src/ports/esp32s3/NativeSerialFiles.cpp','state.observer(sid,seq,op,wait,deadline);}});','''state.observer(sid,seq,op,wait,deadline);},
     stat?+[](uint32_t sid,uint32_t seq,uint64_t ns,int32_t rc,const RiscBoot::StatObservation& value){state.stat(sid,seq,ns,rc,value);}:nullptr});''')
edit('src/diagnostics/Journal.h','#include "Checkpoint.h"','#include "Checkpoint.h"\n#include "SerialStat.h"')
edit('src/diagnostics/Journal.h','const Checkpoint* checkpoint=nullptr){','const Checkpoint* checkpoint=nullptr,const SerialStatSnapshot* stat=nullptr){')
edit('src/diagnostics/Journal.h','        snapshot_=current;checkpoint_=checkpoint?*checkpoint:Checkpoint{};','        snapshot_=current;checkpoint_=checkpoint?*checkpoint:Checkpoint{};stat_=stat?*stat:SerialStatSnapshot{};')
edit('src/diagnostics/Journal.h','checkpointLines()+1)active_=false;','checkpointLines()+statLines(stat_)+1)active_=false;')
edit('src/diagnostics/Journal.h','    }else length=std::snprintf(line_,sizeof(line_),"RTE_DIAG end\\n");','''    }else if(index_<=snapshot_.eventCount+snapshot_.messageCount+checkpointLines()+statLines(stat_)){
      length=statLine(stat_,unsigned(index_-snapshot_.eventCount-snapshot_.messageCount-checkpointLines()-1),line_,sizeof(line_));
    }else length=std::snprintf(line_,sizeof(line_),"RTE_DIAG end\\n");''')
edit('src/diagnostics/Journal.h','  Checkpoint checkpoint_{};','  Checkpoint checkpoint_{};\n  SerialStatSnapshot stat_{};')
edit('src/ports/esp32s3/SleepDiagnostics.h','#include <cstdint>','#include <cstdint>\n#include "bootstrap/StatObservation.h"')
edit('src/ports/esp32s3/SleepDiagnostics.h','void serialControl(uint32_t session','void serialStat(uint32_t session,uint32_t sequence,uint64_t ns,int32_t status,const RiscBoot::StatObservation&);\nvoid serialControl(uint32_t session')
edit('src/ports/esp32s3/SleepDiagnostics.cpp','  Checkpoint checkpoint;','  Checkpoint checkpoint;\n  SerialStatSnapshot stat{};')
edit('src/ports/esp32s3/SleepDiagnostics.cpp','Checkpoint& checkpointState(){return replayWorkspace().checkpoint;}','Checkpoint& checkpointState(){return replayWorkspace().checkpoint;}\nSerialStatSnapshot& statState(){return replayWorkspace().stat;}')
edit('src/ports/esp32s3/SleepDiagnostics.cpp','Checkpoint lastCheckpoint;','Checkpoint lastCheckpoint;\nSerialStatSnapshot lastStat{};')
edit('src/ports/esp32s3/SleepDiagnostics.cpp','Checkpoint& checkpointState(){return lastCheckpoint;}','Checkpoint& checkpointState(){return lastCheckpoint;}\nSerialStatSnapshot& statState(){return lastStat;}')
edit('src/ports/esp32s3/SleepDiagnostics.cpp','void serialControl(uint32_t session','''void serialStat(uint32_t sid,uint32_t seq,uint64_t ns,int32_t status,const RiscBoot::StatObservation& decision){
  if(!ours() || xPortInIsrContext())return;
  observeStat(statState(),RiscPlatform::millis(),sid,seq,ns,status,decision);
}
void serialControl(uint32_t session''')
edit('src/ports/esp32s3/SleepDiagnostics.cpp','sleepReplay().disconnect();checkpointState()={};','sleepReplay().disconnect();checkpointState()={};statState()={};')
edit('src/ports/esp32s3/SleepDiagnostics.cpp','sleepReplay().input(char(c),journal,&checkpointState());','sleepReplay().input(char(c),journal,&checkpointState(),&statState());')
edit('src/main.cpp','''    })){
    diagnosticLine("RTE_BOOT error=serial-file-admission");''','''    },
#if RISC_SLEEP_DIAGNOSTICS
    [](uint32_t sid,uint32_t seq,uint64_t ns,int32_t status,const RiscBoot::StatObservation& decision){RiscDiagnostics::serialStat(sid,seq,ns,status,decision);}
#else
    nullptr
#endif
    )){
    diagnosticLine("RTE_BOOT error=serial-file-admission");''')
