# Fresh candidate receipts

Candidate d4f1768461bfba9730be86641e06dce2b24f4c92, tree cbd088ae2e72ce16fc9f0536100651b69c955b1c. Base 584067ddeb6e3170be25261a99c2c1e7912090ee. All files here are new qualification, not recovered historical receipts. Files under ../historical and ../retained-text have separate provenance.

- initial-baseline-candidate.log: baseline and candidate normal protocol + storage adapter/C ABI.
- provider-final-normal.log and provider-final-sanitized.log: final 10-case released-provider baseline/off/on parity; each matching directory contains per-case wire/call-count outputs, complete commands and SHA256 manifest of Runtime/provider/header inputs. Earlier provider-normal/sanitized are successful intermediate runs before a comment-only header update; final runs are authoritative.
- focused-unit.log: caller-owned capture and production diagnostic adapter normal tests.
- focused-unit-sanitized-noleaks.log: same tests with ASan+UBSan and stack-use-after-return detection.
- focused-unit-sanitized.log: retained failed first attempt, LeakSanitizer cannot operate under ptrace. This is not a successful qualification; leak detection remains excluded.
- regressions.log: both revisions, normal and ASan+UBSan; protocol, adapter/C ABI, checkpoint and journal/HWCDC suites.
- focused-native.log: retained first compile failure from fixture namespace typo.
- focused-native-v2.log: retained fixture sequence-order assertion failure.
- focused-native-v3.log and focused-native-sanitized.log: corrected native fixtures pass external=0 and external=1, normal/sanitized.
- native-workspace.log and native-workspace-headers.log: retained missing official header attempts, not qualification. Only esp_err.h and esp_compiler.h were then fetched from official pinned ESP-IDF fff9895c82d744c7237be8847347bdd1b07c6643.
- native-workspace-complete-headers.log: first successful candidate six-config native workspace run.
- native-workspace-parity.log: both revisions, both sanitizer modes, each six configurations.
- memory.log and memory/measurement.json: exact GCC14.2.0 host object/type commands, section sizes and symbols. No target size or link-time flash claim.
- restore.log: bundle applied over baseline in a new repository, exact candidate tree confirmed, focused unit/production diagnostic tests rerun successfully.
- final-source-verification.log: final provider input manifests rechecked after freeze.

Reproduction source/scripts are committed in runtime/test. Runtime docs/STAT_OBSERVATION_CANDIDATE.md documents commands, interpretation, flags, ownership/timing, resource costs and retrieval limitations. The runner output directory must be absent before each run.

Full reproduction command history for focused provider and memory runs is inside their JSON files. Existing regression execution was:

```sh
export ASAN_OPTIONS=detect_leaks=0:detect_stack_use_after_return=1
for repo in ../baseline .; do for san in 0 1; do
  for script in run_serial_files_test.sh run_storage_files_adapter_test.sh run_diagnostic_checkpoint_test.sh run_diagnostic_journal_test.sh; do
    SANITIZE=$san bash "$repo/test/$script"
  done
done; done
export IDF_PATH="$PWD/../idf-headers"
for repo in ../baseline .; do for san in 0 1; do
  SANITIZE=$san bash "$repo/test/run_native_diagnostic_workspace_test.sh"
done; done
SANITIZE=1 bash test/run_stat_observation_unit_test.sh
SANITIZE=1 bash test/run_stat_observation_native_test.sh
```

All execution is host source qualification with RAM media/shims. No device, full product, USB/physical SD, toolchain target build or publication occurred. The callback does not create a retained/stopped Runtime diagnostic service path.
