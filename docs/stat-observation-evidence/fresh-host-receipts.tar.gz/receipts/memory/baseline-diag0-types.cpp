#include "ports/esp32s3/NativeSerialFiles.cpp"
#include "ports/esp32s3/SleepDiagnostics.cpp"
extern "C" {
char measure_client[sizeof(RiscBoot::RuntimeFiles)];
char measure_adapter[sizeof(RiscBoot::StorageFilesVolumeAdapter)];
char measure_endpoint[sizeof(RiscSerial::Files)];
char measure_hooks[sizeof(RiscSerial::Hooks)];
char measure_native_state[sizeof(RiscCpu::NativeSerialFiles::state)];
char measure_native_workspace[sizeof(RiscCpu::NativeSerialFiles::workspaceStorage)];
#if RISC_SLEEP_DIAGNOSTICS
char measure_replay[sizeof(RiscDiagnostics::Replay)];
char measure_diagnostic_workspace[sizeof(RiscDiagnostics::replayStorage)];
#endif
}
