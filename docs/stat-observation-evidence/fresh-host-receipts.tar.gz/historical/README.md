# Historical evidence only, not recovered artifacts

At 23:19:06 UTC on 2026-10-17, the old executor's observation worktree, base checkout/common Git repository, provider checkout, raw receipts and all /tmp recovery files were absent. No complete bundle/patch bytes were cached by this worker. The parent may have independent records; none are assumed here.

Lost checkpoint: bdb9545e58ab776a0cfd4268c305bac71c9d16c6.
Lost frozen base: 4d58f201be34f170b4fed55fd6744086804c4caf.
Verified public ancestor at the historical run: 48229bd1593a2e24e95bf4537b495ee615990fd3, tree3958854e85c4dfc40be7cb3f5256172a184ddee1.
Historical bundle:686558 bytes, SHA256 f703d1eaa4d06d44e87142b356ee95bcf0d81307241aa587654da45020b8f9a1.
Historical recovery.patch.gz:719854 bytes, SHA256 f8cdfdd71a6796d1820d9c8d3922a220d046277a017a4c65cad5ef62d33d2197.
Historical source.diff SHA2566554c5f9a90a2a8d200e6a86b24ff04d1c6b91293b592e6ec66ea746664704d3.
Historical manifest SHA25698c7ebd2d4cbe3f6405e7302e3747b05fe6b8aacee3a93b84c87faecaf6a9912.

Tool output recorded bundle verification, patch applicability against the public ancestor, and139 manifest file checks. Historical tests passed10 released-provider controls normal/ASan+UBSan,8 diagnostic-pump combinations normal/sanitized,11 protocol scenarios normal/sanitized,5394 adapter checks normally, and ordinary native transport. Native transport sanitizer failed on ArduinoJson -Werror=maybe-uninitialized without a frozen-base control; adapter sanitizer link failed ENOSPC. These records do not qualify any reconstructed source.

Historical target sizes:24-byte observation; snapshot188→264; actual diagnostic external static+152; native internal static+4; RuntimeFiles168/adapter148/endpoint1408/Runtime324856/native workspace2816 unchanged. Object-only X4 ESP32-S3 IDF6.1 compilation, no linked product or hardware qualification. These measurements apply only to the lost checkpoint.

The small StatObservation.h file in retained-text is transcribed verbatim from the complete numbered source output. Other retained source excerpts and script bodies are transcribed from tool-call text with provenance noted; they are not a recovered Git tree. Reconstructed code under runtime is a NEW candidate on public584067ddeb6e3170be25261a99c2c1e7912090ee and must receive new hashes/tests. No exact equivalence to the lost checkpoint is claimed.
